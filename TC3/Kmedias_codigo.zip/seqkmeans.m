% Implementacao do algoritmo K-medias sequencial
%
% Autor: Guilherme Barreto
% Data: 20/11/2018 
%
clear; clc; close all;

X=load('dataset1.dat'); % Leitura do conjunto de dados
[N M]=size(X);

K=4;  % Numero de prototipos escolhido

% Posicao inicial dos prototipos
I=randperm(N,K);
W=X(I,:);   % Seleciona aleatoriamente K exemplos do conjunto de dados 
%W=zeros(K,2);  % Inicia prototipos com zero.

figure; 
plot(X(:,1),X(:,2),'ro',W(:,1),W(:,2),'cd')

Ne=20;   % Numero de epocas de treinamento
lr=0.1;  % Passo de aprendizagem

for r=1:Ne,

  % Embaralha conjunto de dados a cada epoca de treinamento
  I=randperm(N); X=X(I,:);
  
  % Busca pelo prototipo mais proximo do vetor de atributos atual
  soma=0;
  for t=1:N,
    for i=1:K,
      Dist2(i)=norm(X(t,:)-W(i,:));
    end
    [dummy Istar]=min(Dist2);   % Indice do prototipo mais proximo
    
    aux=X(t,:)-W(Istar,:);
    soma=soma+aux*aux';     % Usado no calculo do SSD por epoca

    % Atualiza posicao do prototipo mais proximo
    W(Istar,:) = W(Istar,:) + lr*aux;
  end
  
  SSD(r)=soma;
  
end

% Mostra posicao final dos prototipos
figure; 
plot(X(:,1),X(:,2),'ro',W(:,1),W(:,2),'b*')

%plot(W(:,1),W(:,2),'gd');

% Mostra evolucao do SSD ao longo das epocas de treinamento
figure; plot(SSD); xlabel('Epocas de treinamento');
ylabel('SSD'); title('SSD por epoca de treinamento')

% Realiza particao pos-treinamento do conjunto original em K subconjuntos
for t=1:N,
    for i=1:K,
      Dist2(i)=norm(X(t,:)-W(i,:));
    end
    [dummy Istar]=min(Dist2);   % Indice do prototipo mais proximo
    
    Icluster(t)=Istar; 
end

for k=1:K,
    I=find(Icluster==k); % Indice de todos os exemplos mais proximos do prototipo W_k
    Particao{k}=X(I,:);  % Separa todos os exemplos da k-esima particao
end




